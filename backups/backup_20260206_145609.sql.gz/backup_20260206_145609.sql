--
-- PostgreSQL database dump
--

\restrict d4ix1xmMMi68bXYCOaUQPUmEGSCyLE8F8r2gZbfRYDpOfMhFUcfCWd6mOh7xyif

-- Dumped from database version 16.11
-- Dumped by pg_dump version 16.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: accounts_payable; Type: TABLE; Schema: public; Owner: serviceflow
--

CREATE TABLE public.accounts_payable (
    id integer NOT NULL,
    supplier_id integer NOT NULL,
    purchase_order_id integer,
    total_amount numeric(10,2) NOT NULL,
    paid_amount numeric(10,2),
    due_date date NOT NULL,
    status character varying(20),
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone
);


ALTER TABLE public.accounts_payable OWNER TO serviceflow;

--
-- Name: accounts_payable_id_seq; Type: SEQUENCE; Schema: public; Owner: serviceflow
--

CREATE SEQUENCE public.accounts_payable_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.accounts_payable_id_seq OWNER TO serviceflow;

--
-- Name: accounts_payable_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: serviceflow
--

ALTER SEQUENCE public.accounts_payable_id_seq OWNED BY public.accounts_payable.id;


--
-- Name: accounts_receivable; Type: TABLE; Schema: public; Owner: serviceflow
--

CREATE TABLE public.accounts_receivable (
    id integer NOT NULL,
    customer_id integer NOT NULL,
    sale_id integer,
    repair_id integer,
    total_amount numeric(10,2) NOT NULL,
    paid_amount numeric(10,2),
    exchange_rate_at_time numeric(18,6),
    due_date date NOT NULL,
    status character varying(20),
    notes character varying(500),
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone,
    paid_at timestamp with time zone,
    created_by integer
);


ALTER TABLE public.accounts_receivable OWNER TO serviceflow;

--
-- Name: accounts_receivable_id_seq; Type: SEQUENCE; Schema: public; Owner: serviceflow
--

CREATE SEQUENCE public.accounts_receivable_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.accounts_receivable_id_seq OWNER TO serviceflow;

--
-- Name: accounts_receivable_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: serviceflow
--

ALTER SEQUENCE public.accounts_receivable_id_seq OWNED BY public.accounts_receivable.id;


--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: serviceflow
--

CREATE TABLE public.audit_logs (
    id integer NOT NULL,
    user_id integer,
    action character varying(50) NOT NULL,
    target_type character varying(50) NOT NULL,
    target_id integer,
    details json,
    ip_address character varying(45),
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.audit_logs OWNER TO serviceflow;

--
-- Name: audit_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: serviceflow
--

CREATE SEQUENCE public.audit_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.audit_logs_id_seq OWNER TO serviceflow;

--
-- Name: audit_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: serviceflow
--

ALTER SEQUENCE public.audit_logs_id_seq OWNED BY public.audit_logs.id;


--
-- Name: cash_sessions; Type: TABLE; Schema: public; Owner: serviceflow
--

CREATE TABLE public.cash_sessions (
    id integer NOT NULL,
    user_id integer NOT NULL,
    session_code character varying(50) NOT NULL,
    status character varying(20),
    opening_amount numeric(10,2),
    opening_amount_ves numeric(20,2),
    expected_amount numeric(10,2),
    expected_amount_ves numeric(20,2),
    actual_amount numeric(10,2),
    actual_amount_ves numeric(20,2),
    shortage numeric(10,2),
    overage numeric(10,2),
    shortage_ves numeric(20,2),
    overage_ves numeric(20,2),
    opened_at timestamp with time zone DEFAULT now(),
    closed_at timestamp with time zone,
    notes character varying(255)
);


ALTER TABLE public.cash_sessions OWNER TO serviceflow;

--
-- Name: cash_sessions_id_seq; Type: SEQUENCE; Schema: public; Owner: serviceflow
--

CREATE SEQUENCE public.cash_sessions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.cash_sessions_id_seq OWNER TO serviceflow;

--
-- Name: cash_sessions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: serviceflow
--

ALTER SEQUENCE public.cash_sessions_id_seq OWNED BY public.cash_sessions.id;


--
-- Name: cash_transactions; Type: TABLE; Schema: public; Owner: serviceflow
--

CREATE TABLE public.cash_transactions (
    id integer NOT NULL,
    session_id integer NOT NULL,
    transaction_type character varying(20) NOT NULL,
    amount_usd numeric(10,2) NOT NULL,
    amount_ves numeric(20,2) NOT NULL,
    exchange_rate numeric(18,6) NOT NULL,
    currency character varying(3),
    description character varying(255),
    reference_id integer,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.cash_transactions OWNER TO serviceflow;

--
-- Name: cash_transactions_id_seq; Type: SEQUENCE; Schema: public; Owner: serviceflow
--

CREATE SEQUENCE public.cash_transactions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.cash_transactions_id_seq OWNER TO serviceflow;

--
-- Name: cash_transactions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: serviceflow
--

ALTER SEQUENCE public.cash_transactions_id_seq OWNED BY public.cash_transactions.id;


--
-- Name: categories; Type: TABLE; Schema: public; Owner: serviceflow
--

CREATE TABLE public.categories (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    description text,
    type character varying(50),
    is_active boolean
);


ALTER TABLE public.categories OWNER TO serviceflow;

--
-- Name: categories_id_seq; Type: SEQUENCE; Schema: public; Owner: serviceflow
--

CREATE SEQUENCE public.categories_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.categories_id_seq OWNER TO serviceflow;

--
-- Name: categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: serviceflow
--

ALTER SEQUENCE public.categories_id_seq OWNED BY public.categories.id;


--
-- Name: customer_payments; Type: TABLE; Schema: public; Owner: serviceflow
--

CREATE TABLE public.customer_payments (
    id integer NOT NULL,
    account_id integer NOT NULL,
    customer_id integer NOT NULL,
    session_id integer,
    amount_usd numeric(10,2) NOT NULL,
    amount_ves numeric(20,2) NOT NULL,
    exchange_rate numeric(18,6) NOT NULL,
    balance_before numeric(10,2) NOT NULL,
    balance_after numeric(10,2) NOT NULL,
    payment_method character varying(50) NOT NULL,
    currency character varying(3),
    reference character varying(100),
    notes character varying(255),
    payment_date timestamp with time zone DEFAULT now(),
    created_by integer
);


ALTER TABLE public.customer_payments OWNER TO serviceflow;

--
-- Name: customer_payments_id_seq; Type: SEQUENCE; Schema: public; Owner: serviceflow
--

CREATE SEQUENCE public.customer_payments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.customer_payments_id_seq OWNER TO serviceflow;

--
-- Name: customer_payments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: serviceflow
--

ALTER SEQUENCE public.customer_payments_id_seq OWNED BY public.customer_payments.id;


--
-- Name: customers; Type: TABLE; Schema: public; Owner: serviceflow
--

CREATE TABLE public.customers (
    id integer NOT NULL,
    name character varying(200) NOT NULL,
    email character varying(255),
    phone character varying(20),
    address text,
    city character varying(100),
    country character varying(100),
    dni character varying(20),
    dni_type character varying(1),
    notes text,
    loyalty_points integer,
    credit_limit numeric(10,2),
    current_debt numeric(10,2),
    payment_terms integer,
    credit_status character varying(20),
    credit_score integer,
    last_payment_date date,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone
);


ALTER TABLE public.customers OWNER TO serviceflow;

--
-- Name: customers_id_seq; Type: SEQUENCE; Schema: public; Owner: serviceflow
--

CREATE SEQUENCE public.customers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.customers_id_seq OWNER TO serviceflow;

--
-- Name: customers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: serviceflow
--

ALTER SEQUENCE public.customers_id_seq OWNED BY public.customers.id;


--
-- Name: exchange_rates; Type: TABLE; Schema: public; Owner: serviceflow
--

CREATE TABLE public.exchange_rates (
    id integer NOT NULL,
    base_currency character varying(3) NOT NULL,
    target_currency character varying(3) NOT NULL,
    rate numeric(18,6) NOT NULL,
    source character varying(50) NOT NULL,
    effective_date date NOT NULL,
    is_active boolean,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.exchange_rates OWNER TO serviceflow;

--
-- Name: exchange_rates_id_seq; Type: SEQUENCE; Schema: public; Owner: serviceflow
--

CREATE SEQUENCE public.exchange_rates_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.exchange_rates_id_seq OWNER TO serviceflow;

--
-- Name: exchange_rates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: serviceflow
--

ALTER SEQUENCE public.exchange_rates_id_seq OWNED BY public.exchange_rates.id;


--
-- Name: expense_categories; Type: TABLE; Schema: public; Owner: serviceflow
--

CREATE TABLE public.expense_categories (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    description character varying(255),
    is_active boolean
);


ALTER TABLE public.expense_categories OWNER TO serviceflow;

--
-- Name: expense_categories_id_seq; Type: SEQUENCE; Schema: public; Owner: serviceflow
--

CREATE SEQUENCE public.expense_categories_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.expense_categories_id_seq OWNER TO serviceflow;

--
-- Name: expense_categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: serviceflow
--

ALTER SEQUENCE public.expense_categories_id_seq OWNED BY public.expense_categories.id;


--
-- Name: expenses; Type: TABLE; Schema: public; Owner: serviceflow
--

CREATE TABLE public.expenses (
    id integer NOT NULL,
    category_id integer NOT NULL,
    session_id integer,
    user_id integer NOT NULL,
    description character varying(255) NOT NULL,
    amount numeric(10,2) NOT NULL,
    currency character varying(3) NOT NULL,
    exchange_rate numeric(18,6) NOT NULL,
    amount_usd numeric(10,2) NOT NULL,
    payment_method character varying(50) NOT NULL,
    date date DEFAULT CURRENT_DATE NOT NULL,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.expenses OWNER TO serviceflow;

--
-- Name: expenses_id_seq; Type: SEQUENCE; Schema: public; Owner: serviceflow
--

CREATE SEQUENCE public.expenses_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.expenses_id_seq OWNER TO serviceflow;

--
-- Name: expenses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: serviceflow
--

ALTER SEQUENCE public.expenses_id_seq OWNED BY public.expenses.id;


--
-- Name: inventory; Type: TABLE; Schema: public; Owner: serviceflow
--

CREATE TABLE public.inventory (
    id integer NOT NULL,
    product_id integer,
    quantity integer,
    min_stock integer,
    max_stock integer,
    location character varying(100),
    last_updated timestamp with time zone
);


ALTER TABLE public.inventory OWNER TO serviceflow;

--
-- Name: inventory_id_seq; Type: SEQUENCE; Schema: public; Owner: serviceflow
--

CREATE SEQUENCE public.inventory_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.inventory_id_seq OWNER TO serviceflow;

--
-- Name: inventory_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: serviceflow
--

ALTER SEQUENCE public.inventory_id_seq OWNED BY public.inventory.id;


--
-- Name: inventory_logs; Type: TABLE; Schema: public; Owner: serviceflow
--

CREATE TABLE public.inventory_logs (
    id integer NOT NULL,
    inventory_id integer,
    product_id integer,
    user_id integer,
    old_quantity integer NOT NULL,
    new_quantity integer NOT NULL,
    adjustment integer NOT NULL,
    reason text,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.inventory_logs OWNER TO serviceflow;

--
-- Name: inventory_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: serviceflow
--

CREATE SEQUENCE public.inventory_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.inventory_logs_id_seq OWNER TO serviceflow;

--
-- Name: inventory_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: serviceflow
--

ALTER SEQUENCE public.inventory_logs_id_seq OWNED BY public.inventory_logs.id;


--
-- Name: notifications; Type: TABLE; Schema: public; Owner: serviceflow
--

CREATE TABLE public.notifications (
    id integer NOT NULL,
    user_id integer,
    title character varying(255) NOT NULL,
    message text NOT NULL,
    is_read boolean,
    type character varying(50),
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.notifications OWNER TO serviceflow;

--
-- Name: notifications_id_seq; Type: SEQUENCE; Schema: public; Owner: serviceflow
--

CREATE SEQUENCE public.notifications_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.notifications_id_seq OWNER TO serviceflow;

--
-- Name: notifications_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: serviceflow
--

ALTER SEQUENCE public.notifications_id_seq OWNED BY public.notifications.id;


--
-- Name: payments; Type: TABLE; Schema: public; Owner: serviceflow
--

CREATE TABLE public.payments (
    id integer NOT NULL,
    sale_id integer,
    repair_id integer,
    session_id integer,
    amount_usd numeric(10,2) NOT NULL,
    amount_ves numeric(20,2) NOT NULL,
    exchange_rate numeric(18,6) NOT NULL,
    payment_method character varying(50) NOT NULL,
    currency character varying(3),
    reference character varying(100),
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.payments OWNER TO serviceflow;

--
-- Name: payments_id_seq; Type: SEQUENCE; Schema: public; Owner: serviceflow
--

CREATE SEQUENCE public.payments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.payments_id_seq OWNER TO serviceflow;

--
-- Name: payments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: serviceflow
--

ALTER SEQUENCE public.payments_id_seq OWNED BY public.payments.id;


--
-- Name: products; Type: TABLE; Schema: public; Owner: serviceflow
--

CREATE TABLE public.products (
    id integer NOT NULL,
    sku character varying(50),
    name character varying(255) NOT NULL,
    description text,
    price_usd numeric(10,2) NOT NULL,
    cost_usd numeric(10,2) NOT NULL,
    category_id integer,
    brand character varying(100),
    model character varying(100),
    is_active boolean
);


ALTER TABLE public.products OWNER TO serviceflow;

--
-- Name: products_id_seq; Type: SEQUENCE; Schema: public; Owner: serviceflow
--

CREATE SEQUENCE public.products_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.products_id_seq OWNER TO serviceflow;

--
-- Name: products_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: serviceflow
--

ALTER SEQUENCE public.products_id_seq OWNED BY public.products.id;


--
-- Name: purchase_items; Type: TABLE; Schema: public; Owner: serviceflow
--

CREATE TABLE public.purchase_items (
    id integer NOT NULL,
    purchase_id integer NOT NULL,
    product_id integer NOT NULL,
    quantity integer NOT NULL,
    unit_cost_usd numeric(10,2) NOT NULL,
    subtotal_usd numeric(10,2) NOT NULL,
    received_quantity integer
);


ALTER TABLE public.purchase_items OWNER TO serviceflow;

--
-- Name: purchase_items_id_seq; Type: SEQUENCE; Schema: public; Owner: serviceflow
--

CREATE SEQUENCE public.purchase_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.purchase_items_id_seq OWNER TO serviceflow;

--
-- Name: purchase_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: serviceflow
--

ALTER SEQUENCE public.purchase_items_id_seq OWNED BY public.purchase_items.id;


--
-- Name: purchase_orders; Type: TABLE; Schema: public; Owner: serviceflow
--

CREATE TABLE public.purchase_orders (
    id integer NOT NULL,
    supplier_id integer NOT NULL,
    user_id integer NOT NULL,
    status character varying(20),
    total_amount_usd numeric(10,2),
    expected_date date,
    received_date timestamp with time zone,
    notes text,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone
);


ALTER TABLE public.purchase_orders OWNER TO serviceflow;

--
-- Name: purchase_orders_id_seq; Type: SEQUENCE; Schema: public; Owner: serviceflow
--

CREATE SEQUENCE public.purchase_orders_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.purchase_orders_id_seq OWNER TO serviceflow;

--
-- Name: purchase_orders_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: serviceflow
--

ALTER SEQUENCE public.purchase_orders_id_seq OWNED BY public.purchase_orders.id;


--
-- Name: repair_items; Type: TABLE; Schema: public; Owner: serviceflow
--

CREATE TABLE public.repair_items (
    id integer NOT NULL,
    repair_id integer,
    product_id integer,
    quantity integer,
    unit_cost_usd numeric(10,2)
);


ALTER TABLE public.repair_items OWNER TO serviceflow;

--
-- Name: repair_items_id_seq; Type: SEQUENCE; Schema: public; Owner: serviceflow
--

CREATE SEQUENCE public.repair_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.repair_items_id_seq OWNER TO serviceflow;

--
-- Name: repair_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: serviceflow
--

ALTER SEQUENCE public.repair_items_id_seq OWNED BY public.repair_items.id;


--
-- Name: repair_logs; Type: TABLE; Schema: public; Owner: serviceflow
--

CREATE TABLE public.repair_logs (
    id integer NOT NULL,
    repair_id integer,
    user_id integer,
    status_from character varying(20),
    status_to character varying(20),
    notes text,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.repair_logs OWNER TO serviceflow;

--
-- Name: repair_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: serviceflow
--

CREATE SEQUENCE public.repair_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.repair_logs_id_seq OWNER TO serviceflow;

--
-- Name: repair_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: serviceflow
--

ALTER SEQUENCE public.repair_logs_id_seq OWNED BY public.repair_logs.id;


--
-- Name: repairs; Type: TABLE; Schema: public; Owner: serviceflow
--

CREATE TABLE public.repairs (
    id integer NOT NULL,
    customer_id integer,
    user_id integer,
    created_by_id integer,
    device_model character varying(100) NOT NULL,
    device_imei character varying(50),
    problem_description text NOT NULL,
    technical_report text,
    status character varying(20),
    service_type character varying(20),
    quick_service_tag character varying(50),
    missing_part_note text,
    repair_type character varying(20),
    estimated_cost_usd numeric(10,2),
    labor_cost_usd numeric(10,2),
    final_cost_usd numeric(10,2),
    paid_amount_usd numeric(10,2),
    delivered_at timestamp with time zone,
    warranty_expiration timestamp with time zone,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.repairs OWNER TO serviceflow;

--
-- Name: repairs_id_seq; Type: SEQUENCE; Schema: public; Owner: serviceflow
--

CREATE SEQUENCE public.repairs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.repairs_id_seq OWNER TO serviceflow;

--
-- Name: repairs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: serviceflow
--

ALTER SEQUENCE public.repairs_id_seq OWNED BY public.repairs.id;


--
-- Name: roles; Type: TABLE; Schema: public; Owner: serviceflow
--

CREATE TABLE public.roles (
    id integer NOT NULL,
    name character varying(50) NOT NULL,
    description character varying(255)
);


ALTER TABLE public.roles OWNER TO serviceflow;

--
-- Name: roles_id_seq; Type: SEQUENCE; Schema: public; Owner: serviceflow
--

CREATE SEQUENCE public.roles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.roles_id_seq OWNER TO serviceflow;

--
-- Name: roles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: serviceflow
--

ALTER SEQUENCE public.roles_id_seq OWNED BY public.roles.id;


--
-- Name: sale_items; Type: TABLE; Schema: public; Owner: serviceflow
--

CREATE TABLE public.sale_items (
    id integer NOT NULL,
    sale_id integer,
    product_id integer,
    quantity integer NOT NULL,
    unit_price_usd numeric(10,2) NOT NULL,
    unit_cost_usd numeric(10,2) NOT NULL,
    subtotal_usd numeric(10,2) NOT NULL
);


ALTER TABLE public.sale_items OWNER TO serviceflow;

--
-- Name: sale_items_id_seq; Type: SEQUENCE; Schema: public; Owner: serviceflow
--

CREATE SEQUENCE public.sale_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.sale_items_id_seq OWNER TO serviceflow;

--
-- Name: sale_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: serviceflow
--

ALTER SEQUENCE public.sale_items_id_seq OWNED BY public.sale_items.id;


--
-- Name: sale_repairs; Type: TABLE; Schema: public; Owner: serviceflow
--

CREATE TABLE public.sale_repairs (
    sale_id integer NOT NULL,
    repair_id integer NOT NULL,
    amount_allocated_usd numeric(10,2) NOT NULL
);


ALTER TABLE public.sale_repairs OWNER TO serviceflow;

--
-- Name: sale_return_items; Type: TABLE; Schema: public; Owner: serviceflow
--

CREATE TABLE public.sale_return_items (
    id integer NOT NULL,
    sale_return_id integer NOT NULL,
    product_id integer NOT NULL,
    quantity integer NOT NULL,
    unit_price_usd numeric(10,2) NOT NULL
);


ALTER TABLE public.sale_return_items OWNER TO serviceflow;

--
-- Name: sale_return_items_id_seq; Type: SEQUENCE; Schema: public; Owner: serviceflow
--

CREATE SEQUENCE public.sale_return_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.sale_return_items_id_seq OWNER TO serviceflow;

--
-- Name: sale_return_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: serviceflow
--

ALTER SEQUENCE public.sale_return_items_id_seq OWNED BY public.sale_return_items.id;


--
-- Name: sale_returns; Type: TABLE; Schema: public; Owner: serviceflow
--

CREATE TABLE public.sale_returns (
    id integer NOT NULL,
    sale_id integer NOT NULL,
    user_id integer NOT NULL,
    total_amount_usd numeric(10,2) NOT NULL,
    reason character varying(255),
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.sale_returns OWNER TO serviceflow;

--
-- Name: sale_returns_id_seq; Type: SEQUENCE; Schema: public; Owner: serviceflow
--

CREATE SEQUENCE public.sale_returns_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.sale_returns_id_seq OWNER TO serviceflow;

--
-- Name: sale_returns_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: serviceflow
--

ALTER SEQUENCE public.sale_returns_id_seq OWNED BY public.sale_returns.id;


--
-- Name: sales; Type: TABLE; Schema: public; Owner: serviceflow
--

CREATE TABLE public.sales (
    id integer NOT NULL,
    customer_id integer,
    user_id integer,
    total_usd numeric(10,2) NOT NULL,
    total_ves numeric(20,2) NOT NULL,
    exchange_rate numeric(18,6) NOT NULL,
    exchange_rate_at_time numeric(18,6),
    payment_method character varying(50),
    payment_status character varying(20),
    notes text,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.sales OWNER TO serviceflow;

--
-- Name: sales_id_seq; Type: SEQUENCE; Schema: public; Owner: serviceflow
--

CREATE SEQUENCE public.sales_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.sales_id_seq OWNER TO serviceflow;

--
-- Name: sales_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: serviceflow
--

ALTER SEQUENCE public.sales_id_seq OWNED BY public.sales.id;


--
-- Name: suppliers; Type: TABLE; Schema: public; Owner: serviceflow
--

CREATE TABLE public.suppliers (
    id integer NOT NULL,
    name character varying(200) NOT NULL,
    contact_name character varying(100),
    email character varying(255),
    phone character varying(50),
    address text,
    tax_id character varying(50),
    payment_terms integer,
    notes text,
    is_active boolean,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone
);


ALTER TABLE public.suppliers OWNER TO serviceflow;

--
-- Name: suppliers_id_seq; Type: SEQUENCE; Schema: public; Owner: serviceflow
--

CREATE SEQUENCE public.suppliers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.suppliers_id_seq OWNER TO serviceflow;

--
-- Name: suppliers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: serviceflow
--

ALTER SEQUENCE public.suppliers_id_seq OWNED BY public.suppliers.id;


--
-- Name: system_settings; Type: TABLE; Schema: public; Owner: serviceflow
--

CREATE TABLE public.system_settings (
    id integer NOT NULL,
    company_name character varying(200),
    company_tax_id character varying(50),
    company_address text,
    company_phone character varying(50),
    company_email character varying(100),
    company_logo_url text,
    receipt_header text,
    receipt_footer text,
    receipt_show_tax boolean,
    default_currency character varying(3),
    whatsapp_api_url text,
    whatsapp_token text,
    telegram_token text,
    google_drive_folder_id character varying(100),
    is_active boolean
);


ALTER TABLE public.system_settings OWNER TO serviceflow;

--
-- Name: system_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: serviceflow
--

CREATE SEQUENCE public.system_settings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.system_settings_id_seq OWNER TO serviceflow;

--
-- Name: system_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: serviceflow
--

ALTER SEQUENCE public.system_settings_id_seq OWNED BY public.system_settings.id;


--
-- Name: user_roles; Type: TABLE; Schema: public; Owner: serviceflow
--

CREATE TABLE public.user_roles (
    user_id integer,
    role_id integer
);


ALTER TABLE public.user_roles OWNER TO serviceflow;

--
-- Name: users; Type: TABLE; Schema: public; Owner: serviceflow
--

CREATE TABLE public.users (
    id integer NOT NULL,
    username character varying(50) NOT NULL,
    email character varying(255) NOT NULL,
    hashed_password character varying(255) NOT NULL,
    full_name character varying(100),
    is_active boolean,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone
);


ALTER TABLE public.users OWNER TO serviceflow;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: serviceflow
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO serviceflow;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: serviceflow
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: accounts_payable id; Type: DEFAULT; Schema: public; Owner: serviceflow
--

ALTER TABLE ONLY public.accounts_payable ALTER COLUMN id SET DEFAULT nextval('public.accounts_payable_id_seq'::regclass);


--
-- Name: accounts_receivable id; Type: DEFAULT; Schema: public; Owner: serviceflow
--

ALTER TABLE ONLY public.accounts_receivable ALTER COLUMN id SET DEFAULT nextval('public.accounts_receivable_id_seq'::regclass);


--
-- Name: audit_logs id; Type: DEFAULT; Schema: public; Owner: serviceflow
--

ALTER TABLE ONLY public.audit_logs ALTER COLUMN id SET DEFAULT nextval('public.audit_logs_id_seq'::regclass);


--
-- Name: cash_sessions id; Type: DEFAULT; Schema: public; Owner: serviceflow
--

ALTER TABLE ONLY public.cash_sessions ALTER COLUMN id SET DEFAULT nextval('public.cash_sessions_id_seq'::regclass);


--
-- Name: cash_transactions id; Type: DEFAULT; Schema: public; Owner: serviceflow
--

ALTER TABLE ONLY public.cash_transactions ALTER COLUMN id SET DEFAULT nextval('public.cash_transactions_id_seq'::regclass);


--
-- Name: categories id; Type: DEFAULT; Schema: public; Owner: serviceflow
--

ALTER TABLE ONLY public.categories ALTER COLUMN id SET DEFAULT nextval('public.categories_id_seq'::regclass);


--
-- Name: customer_payments id; Type: DEFAULT; Schema: public; Owner: serviceflow
--

ALTER TABLE ONLY public.customer_payments ALTER COLUMN id SET DEFAULT nextval('public.customer_payments_id_seq'::regclass);


--
-- Name: customers id; Type: DEFAULT; Schema: public; Owner: serviceflow
--

ALTER TABLE ONLY public.customers ALTER COLUMN id SET DEFAULT nextval('public.customers_id_seq'::regclass);


--
-- Name: exchange_rates id; Type: DEFAULT; Schema: public; Owner: serviceflow
--

ALTER TABLE ONLY public.exchange_rates ALTER COLUMN id SET DEFAULT nextval('public.exchange_rates_id_seq'::regclass);


--
-- Name: expense_categories id; Type: DEFAULT; Schema: public; Owner: serviceflow
--

ALTER TABLE ONLY public.expense_categories ALTER COLUMN id SET DEFAULT nextval('public.expense_categories_id_seq'::regclass);


--
-- Name: expenses id; Type: DEFAULT; Schema: public; Owner: serviceflow
--

ALTER TABLE ONLY public.expenses ALTER COLUMN id SET DEFAULT nextval('public.expenses_id_seq'::regclass);


--
-- Name: inventory id; Type: DEFAULT; Schema: public; Owner: serviceflow
--

ALTER TABLE ONLY public.inventory ALTER COLUMN id SET DEFAULT nextval('public.inventory_id_seq'::regclass);


--
-- Name: inventory_logs id; Type: DEFAULT; Schema: public; Owner: serviceflow
--

ALTER TABLE ONLY public.inventory_logs ALTER COLUMN id SET DEFAULT nextval('public.inventory_logs_id_seq'::regclass);


--
-- Name: notifications id; Type: DEFAULT; Schema: public; Owner: serviceflow
--

ALTER TABLE ONLY public.notifications ALTER COLUMN id SET DEFAULT nextval('public.notifications_id_seq'::regclass);


--
-- Name: payments id; Type: DEFAULT; Schema: public; Owner: serviceflow
--

ALTER TABLE ONLY public.payments ALTER COLUMN id SET DEFAULT nextval('public.payments_id_seq'::regclass);


--
-- Name: products id; Type: DEFAULT; Schema: public; Owner: serviceflow
--

ALTER TABLE ONLY public.products ALTER COLUMN id SET DEFAULT nextval('public.products_id_seq'::regclass);


--
-- Name: purchase_items id; Type: DEFAULT; Schema: public; Owner: serviceflow
--

ALTER TABLE ONLY public.purchase_items ALTER COLUMN id SET DEFAULT nextval('public.purchase_items_id_seq'::regclass);


--
-- Name: purchase_orders id; Type: DEFAULT; Schema: public; Owner: serviceflow
--

ALTER TABLE ONLY public.purchase_orders ALTER COLUMN id SET DEFAULT nextval('public.purchase_orders_id_seq'::regclass);


--
-- Name: repair_items id; Type: DEFAULT; Schema: public; Owner: serviceflow
--

ALTER TABLE ONLY public.repair_items ALTER COLUMN id SET DEFAULT nextval('public.repair_items_id_seq'::regclass);


--
-- Name: repair_logs id; Type: DEFAULT; Schema: public; Owner: serviceflow
--

ALTER TABLE ONLY public.repair_logs ALTER COLUMN id SET DEFAULT nextval('public.repair_logs_id_seq'::regclass);


--
-- Name: repairs id; Type: DEFAULT; Schema: public; Owner: serviceflow
--

ALTER TABLE ONLY public.repairs ALTER COLUMN id SET DEFAULT nextval('public.repairs_id_seq'::regclass);


--
-- Name: roles id; Type: DEFAULT; Schema: public; Owner: serviceflow
--

ALTER TABLE ONLY public.roles ALTER COLUMN id SET DEFAULT nextval('public.roles_id_seq'::regclass);


--
-- Name: sale_items id; Type: DEFAULT; Schema: public; Owner: serviceflow
--

ALTER TABLE ONLY public.sale_items ALTER COLUMN id SET DEFAULT nextval('public.sale_items_id_seq'::regclass);


--
-- Name: sale_return_items id; Type: DEFAULT; Schema: public; Owner: serviceflow
--

ALTER TABLE ONLY public.sale_return_items ALTER COLUMN id SET DEFAULT nextval('public.sale_return_items_id_seq'::regclass);


--
-- Name: sale_returns id; Type: DEFAULT; Schema: public; Owner: serviceflow
--

ALTER TABLE ONLY public.sale_returns ALTER COLUMN id SET DEFAULT nextval('public.sale_returns_id_seq'::regclass);


--
-- Name: sales id; Type: DEFAULT; Schema: public; Owner: serviceflow
--

ALTER TABLE ONLY public.sales ALTER COLUMN id SET DEFAULT nextval('public.sales_id_seq'::regclass);


--
-- Name: suppliers id; Type: DEFAULT; Schema: public; Owner: serviceflow
--

ALTER TABLE ONLY public.suppliers ALTER COLUMN id SET DEFAULT nextval('public.suppliers_id_seq'::regclass);


--
-- Name: system_settings id; Type: DEFAULT; Schema: public; Owner: serviceflow
--

ALTER TABLE ONLY public.system_settings ALTER COLUMN id SET DEFAULT nextval('public.system_settings_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: serviceflow
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: accounts_payable; Type: TABLE DATA; Schema: public; Owner: serviceflow
--

COPY public.accounts_payable (id, supplier_id, purchase_order_id, total_amount, paid_amount, due_date, status, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: accounts_receivable; Type: TABLE DATA; Schema: public; Owner: serviceflow
--

COPY public.accounts_receivable (id, customer_id, sale_id, repair_id, total_amount, paid_amount, exchange_rate_at_time, due_date, status, notes, created_at, updated_at, paid_at, created_by) FROM stdin;
1	1	1	\N	30.00	12.00	\N	2026-03-07	partial	Venta #1 - Abono: $12.00	2026-02-05 23:11:09.108154+00	\N	\N	1
\.


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: serviceflow
--

COPY public.audit_logs (id, user_id, action, target_type, target_id, details, ip_address, created_at) FROM stdin;
1	\N	UPDATE	INVENTORY	2	{"new_quantity": 4}	\N	2026-02-05 22:49:01.549985+00
2	\N	UPDATE	INVENTORY	1	{"new_quantity": 2}	\N	2026-02-05 23:07:33.050033+00
3	\N	CREATE	SALE	1	{"total": 30.0, "customer_id": 1}	\N	2026-02-05 23:11:09.108154+00
4	\N	CREATE	SALE	2	{"total": 18.0, "customer_id": 1}	\N	2026-02-05 23:12:11.136185+00
5	\N	UPDATE	INVENTORY	4	{"new_quantity": 9}	\N	2026-02-05 23:15:37.75074+00
6	\N	UPDATE	INVENTORY	2	{"new_quantity": 3}	\N	2026-02-05 23:21:01.476294+00
7	\N	CREATE	SALE	3	{"total": 15.0, "customer_id": 2}	\N	2026-02-05 23:21:01.476294+00
8	\N	UPDATE	INVENTORY	2	{"new_quantity": 2}	\N	2026-02-06 17:50:47.370702+00
9	\N	CREATE	SALE	4	{"total": 10.0, "customer_id": null}	\N	2026-02-06 17:50:47.370702+00
10	\N	UPDATE	INVENTORY	2	{"new_quantity": 0}	\N	2026-02-06 17:51:22.422763+00
11	\N	CREATE	SALE	5	{"total": 20.0, "customer_id": null}	\N	2026-02-06 17:51:22.422763+00
\.


--
-- Data for Name: cash_sessions; Type: TABLE DATA; Schema: public; Owner: serviceflow
--

COPY public.cash_sessions (id, user_id, session_code, status, opening_amount, opening_amount_ves, expected_amount, expected_amount_ves, actual_amount, actual_amount_ves, shortage, overage, shortage_ves, overage_ves, opened_at, closed_at, notes) FROM stdin;
1	1	CAJA-20260205-1-1UG2	closed	1.00	0.00	1.00	17100.00	1.00	17100.00	0.00	0.00	0.00	0.00	2026-02-05 22:43:36.566207+00	2026-02-05 23:22:43.816614+00	\N
2	1	CAJA-20260206-1-8CDM	closed	10.00	0.00	10.00	0.00	10.00	0.00	0.00	0.00	0.00	0.00	2026-02-06 00:51:05.950008+00	2026-02-06 01:09:20.161919+00	\N
3	1	CAJA-20260206-1-WZRE	closed	10.00	0.00	10.00	0.00	10.00	0.00	0.00	0.00	0.00	0.00	2026-02-06 17:29:35.015899+00	2026-02-06 17:30:45.745397+00	\N
4	1	CAJA-20260206-1-BNNR	open	10.00	0.00	10.00	11700.00	\N	\N	0.00	0.00	0.00	0.00	2026-02-06 17:48:08.741566+00	\N	\N
\.


--
-- Data for Name: cash_transactions; Type: TABLE DATA; Schema: public; Owner: serviceflow
--

COPY public.cash_transactions (id, session_id, transaction_type, amount_usd, amount_ves, exchange_rate, currency, description, reference_id, created_at) FROM stdin;
1	1	opening	1.00	0.00	50.000000	USD	Apertura de caja (USD)	\N	2026-02-05 22:43:36.566207+00
2	1	sale	12.00	4560.00	380.000000	VES	Venta #1 (VES) - Abono	1	2026-02-05 23:11:09.108154+00
3	1	sale	18.00	6840.00	380.000000	VES	Venta #2 (VES)	2	2026-02-05 23:12:11.136185+00
4	1	sale	15.00	5700.00	380.000000	VES	Venta #3 (VES)	3	2026-02-05 23:21:01.476294+00
5	1	closing	1.00	17100.00	380.000000	USD	Cierre de caja (USD y VES)	\N	2026-02-05 23:22:43.69347+00
6	2	opening	10.00	0.00	380.000000	USD	Apertura de caja (USD)	\N	2026-02-06 00:51:05.950008+00
7	2	closing	10.00	0.00	380.000000	USD	Cierre de caja (USD y VES)	\N	2026-02-06 01:09:20.040418+00
8	3	opening	10.00	0.00	390.000000	USD	Apertura de caja (USD)	\N	2026-02-06 17:29:35.015899+00
9	3	closing	10.00	0.00	390.000000	USD	Cierre de caja (USD y VES)	\N	2026-02-06 17:30:45.61288+00
10	4	opening	10.00	0.00	390.000000	USD	Apertura de caja (USD)	\N	2026-02-06 17:48:08.741566+00
11	4	sale	10.00	3900.00	390.000000	VES	Venta #4 (VES)	4	2026-02-06 17:50:47.370702+00
12	4	sale	20.00	7800.00	390.000000	VES	Venta #5 (VES)	5	2026-02-06 17:51:22.422763+00
\.


--
-- Data for Name: categories; Type: TABLE DATA; Schema: public; Owner: serviceflow
--

COPY public.categories (id, name, description, type, is_active) FROM stdin;
3	Software	Licencias y programas	service	t
4	Hardware	Equipos completos y componentes mayores	service	t
5	Servicios	Mano de obra y servicios técnicos	service	t
1	Repuestos	Componentes y partes para reparación	physical	t
2	Accesorios	Complementos para equipos y periféricos	physical	t
\.


--
-- Data for Name: customer_payments; Type: TABLE DATA; Schema: public; Owner: serviceflow
--

COPY public.customer_payments (id, account_id, customer_id, session_id, amount_usd, amount_ves, exchange_rate, balance_before, balance_after, payment_method, currency, reference, notes, payment_date, created_by) FROM stdin;
\.


--
-- Data for Name: customers; Type: TABLE DATA; Schema: public; Owner: serviceflow
--

COPY public.customers (id, name, email, phone, address, city, country, dni, dni_type, notes, loyalty_points, credit_limit, current_debt, payment_terms, credit_status, credit_score, last_payment_date, created_at, updated_at) FROM stdin;
2	maria nieves	\N	04161090799	\N	\N	Venezuela	19325094	V	\N	0	0.00	0.00	30	active	100	\N	2026-02-05 22:44:40.08789+00	\N
1	alex paez	alex@serviceflow.com	4144977943	 Saman 1 	\N	Venezuela	20029334	V	\N	0	0.00	18.00	30	active	100	\N	2026-02-05 22:43:07.927197+00	2026-02-05 23:11:09.108154+00
\.


--
-- Data for Name: exchange_rates; Type: TABLE DATA; Schema: public; Owner: serviceflow
--

COPY public.exchange_rates (id, base_currency, target_currency, rate, source, effective_date, is_active, created_at) FROM stdin;
1	USD	VES	380.000000	Manual	2026-02-05	f	2026-02-05 22:25:44.700599+00
2	USD	VES	390.000000	Manual	2026-02-06	t	2026-02-06 15:32:18.138572+00
\.


--
-- Data for Name: expense_categories; Type: TABLE DATA; Schema: public; Owner: serviceflow
--

COPY public.expense_categories (id, name, description, is_active) FROM stdin;
\.


--
-- Data for Name: expenses; Type: TABLE DATA; Schema: public; Owner: serviceflow
--

COPY public.expenses (id, category_id, session_id, user_id, description, amount, currency, exchange_rate, amount_usd, payment_method, date, created_at) FROM stdin;
\.


--
-- Data for Name: inventory; Type: TABLE DATA; Schema: public; Owner: serviceflow
--

COPY public.inventory (id, product_id, quantity, min_stock, max_stock, location, last_updated) FROM stdin;
3	3	10	5	\N	\N	\N
1	1	2	5	\N	\N	2026-02-05 23:07:33.050033+00
4	4	9	5	\N	\N	2026-02-05 23:15:37.75074+00
2	2	0	5	\N	\N	2026-02-06 17:51:22.422763+00
\.


--
-- Data for Name: inventory_logs; Type: TABLE DATA; Schema: public; Owner: serviceflow
--

COPY public.inventory_logs (id, inventory_id, product_id, user_id, old_quantity, new_quantity, adjustment, reason, created_at) FROM stdin;
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: serviceflow
--

COPY public.notifications (id, user_id, title, message, is_read, type, created_at) FROM stdin;
\.


--
-- Data for Name: payments; Type: TABLE DATA; Schema: public; Owner: serviceflow
--

COPY public.payments (id, sale_id, repair_id, session_id, amount_usd, amount_ves, exchange_rate, payment_method, currency, reference, created_at) FROM stdin;
1	1	\N	1	12.00	4560.00	380.000000	cash	VES	\N	2026-02-05 23:11:09.108154+00
2	2	\N	1	18.00	6840.00	380.000000	cash	VES	\N	2026-02-05 23:12:11.136185+00
3	3	\N	1	15.00	5700.00	380.000000	cash	VES	\N	2026-02-05 23:21:01.476294+00
4	4	\N	4	10.00	3900.00	390.000000	cash	VES	\N	2026-02-06 17:50:47.370702+00
5	5	\N	4	20.00	7800.00	390.000000	cash	VES	\N	2026-02-06 17:51:22.422763+00
\.


--
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: serviceflow
--

COPY public.products (id, sku, name, description, price_usd, cost_usd, category_id, brand, model, is_active) FROM stdin;
1	\N	pantallas 	\N	30.00	12.00	1	samsung	a23 ,a33	t
2		forro  360	\N	10.00	2.50	2	samsung	a32, a33	t
3	\N	pin v8	\N	5.00	0.50	\N	generico	tecno,huwei, 	f
4	\N	pin V8	\N	5.00	0.50	1	generico	tecno, infinix 	t
\.


--
-- Data for Name: purchase_items; Type: TABLE DATA; Schema: public; Owner: serviceflow
--

COPY public.purchase_items (id, purchase_id, product_id, quantity, unit_cost_usd, subtotal_usd, received_quantity) FROM stdin;
\.


--
-- Data for Name: purchase_orders; Type: TABLE DATA; Schema: public; Owner: serviceflow
--

COPY public.purchase_orders (id, supplier_id, user_id, status, total_amount_usd, expected_date, received_date, notes, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: repair_items; Type: TABLE DATA; Schema: public; Owner: serviceflow
--

COPY public.repair_items (id, repair_id, product_id, quantity, unit_cost_usd) FROM stdin;
1	1	1	1	30.00
2	2	4	1	5.00
\.


--
-- Data for Name: repair_logs; Type: TABLE DATA; Schema: public; Owner: serviceflow
--

COPY public.repair_logs (id, repair_id, user_id, status_from, status_to, notes, created_at) FROM stdin;
1	1	1	\N	received	Reparación recibida	2026-02-05 23:07:33.050033+00
2	1	1	received	COMPLETED	Estado actualizado desde el listado	2026-02-05 23:10:01.856147+00
3	1	1	COMPLETED	RECEIVED	Estado actualizado desde el listado	2026-02-05 23:10:12.301062+00
4	1	1	RECEIVED	COMPLETED	Estado actualizado desde el listado	2026-02-05 23:10:21.708759+00
5	1	1	COMPLETED	delivered	Entregado via Venta POS #2 (Garantía hasta 2026-02-13)	2026-02-05 23:12:11.136185+00
6	2	1	\N	received	Reparación recibida	2026-02-05 23:15:37.75074+00
7	2	1	received	COMPLETED	Estado actualizado desde el listado	2026-02-05 23:19:07.002206+00
8	2	1	COMPLETED	delivered	Entregado via Venta POS #3 (Garantía hasta 2026-02-13)	2026-02-05 23:21:01.476294+00
9	1	1	delivered	COMPLETED	Estado actualizado desde el listado	2026-02-05 23:37:11.359575+00
10	2	1	delivered	COMPLETED	Estado actualizado desde el listado	2026-02-05 23:37:14.010944+00
11	1	1	COMPLETED	CANCELLED	Estado actualizado desde el listado	2026-02-06 00:27:16.014294+00
12	2	1	COMPLETED	CANCELLED	Estado actualizado desde el listado	2026-02-06 00:27:21.718015+00
\.


--
-- Data for Name: repairs; Type: TABLE DATA; Schema: public; Owner: serviceflow
--

COPY public.repairs (id, customer_id, user_id, created_by_id, device_model, device_imei, problem_description, technical_report, status, service_type, quick_service_tag, missing_part_note, repair_type, estimated_cost_usd, labor_cost_usd, final_cost_usd, paid_amount_usd, delivered_at, warranty_expiration, created_at, updated_at) FROM stdin;
1	1	\N	1	samsung a32	\N	Servicio: Pantalla cambio 	\N	CANCELLED	HARDWARE	SCREEN	\N	hardware	\N	0.00	\N	30.00	2026-02-05 23:12:11.161295+00	2026-02-13 23:12:11.161311+00	2026-02-05 23:07:33.050033+00	2026-02-06 00:27:16.014294+00
2	2	\N	1	tecno  10 pro	\N	pin de carga 	\N	CANCELLED	HARDWARE	PIN_V8	\N	hardware	\N	0.00	\N	5.00	2026-02-05 23:21:01.51878+00	2026-02-13 23:21:01.518801+00	2026-02-05 23:15:37.75074+00	2026-02-06 00:27:21.718015+00
\.


--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: serviceflow
--

COPY public.roles (id, name, description) FROM stdin;
1	admin	Administrador con acceso completo
2	vendedor	Personal de ventas
3	tecnico	Técnico de reparaciones
4	gerente	Gerente de tienda
\.


--
-- Data for Name: sale_items; Type: TABLE DATA; Schema: public; Owner: serviceflow
--

COPY public.sale_items (id, sale_id, product_id, quantity, unit_price_usd, unit_cost_usd, subtotal_usd) FROM stdin;
1	3	2	1	10.00	2.50	10.00
2	4	2	1	10.00	2.50	10.00
3	5	2	2	10.00	2.50	20.00
\.


--
-- Data for Name: sale_repairs; Type: TABLE DATA; Schema: public; Owner: serviceflow
--

COPY public.sale_repairs (sale_id, repair_id, amount_allocated_usd) FROM stdin;
1	1	12.00
2	1	18.00
3	2	5.00
\.


--
-- Data for Name: sale_return_items; Type: TABLE DATA; Schema: public; Owner: serviceflow
--

COPY public.sale_return_items (id, sale_return_id, product_id, quantity, unit_price_usd) FROM stdin;
\.


--
-- Data for Name: sale_returns; Type: TABLE DATA; Schema: public; Owner: serviceflow
--

COPY public.sale_returns (id, sale_id, user_id, total_amount_usd, reason, created_at) FROM stdin;
\.


--
-- Data for Name: sales; Type: TABLE DATA; Schema: public; Owner: serviceflow
--

COPY public.sales (id, customer_id, user_id, total_usd, total_ves, exchange_rate, exchange_rate_at_time, payment_method, payment_status, notes, created_at) FROM stdin;
1	1	1	30.00	11400.00	380.000000	380.000000	cash	partial	abono 	2026-02-05 23:11:09.108154+00
2	1	1	18.00	6840.00	380.000000	380.000000	cash	paid	pago total	2026-02-05 23:12:11.136185+00
3	2	1	15.00	5700.00	380.000000	380.000000	cash	paid	pago 	2026-02-05 23:21:01.476294+00
4	\N	1	10.00	3900.00	390.000000	390.000000	cash	paid	\N	2026-02-06 17:50:47.370702+00
5	\N	1	20.00	7800.00	390.000000	390.000000	cash	paid	\N	2026-02-06 17:51:22.422763+00
\.


--
-- Data for Name: suppliers; Type: TABLE DATA; Schema: public; Owner: serviceflow
--

COPY public.suppliers (id, name, contact_name, email, phone, address, tax_id, payment_terms, notes, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: system_settings; Type: TABLE DATA; Schema: public; Owner: serviceflow
--

COPY public.system_settings (id, company_name, company_tax_id, company_address, company_phone, company_email, company_logo_url, receipt_header, receipt_footer, receipt_show_tax, default_currency, whatsapp_api_url, whatsapp_token, telegram_token, google_drive_folder_id, is_active) FROM stdin;
1	Serviceflow Pro	\N	\N	\N	\N	\N	RIF J-00000000-0\nCalle Principal #123\nCiudad, País	Gracias por su visita.\nGarantía de 30 días en reparaciones.	t	USD	\N	\N	\N	\N	t
\.


--
-- Data for Name: user_roles; Type: TABLE DATA; Schema: public; Owner: serviceflow
--

COPY public.user_roles (user_id, role_id) FROM stdin;
1	1
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: serviceflow
--

COPY public.users (id, username, email, hashed_password, full_name, is_active, created_at, updated_at) FROM stdin;
1	admin	admin@serviceflow.com	$2b$12$rTqKrvbm34Gyquwz6k7bmebXV8VoyYeoNj8ulkZuTfFW17VIp8.5G	System Administrator	t	2026-02-05 22:25:44.234045+00	\N
\.


--
-- Name: accounts_payable_id_seq; Type: SEQUENCE SET; Schema: public; Owner: serviceflow
--

SELECT pg_catalog.setval('public.accounts_payable_id_seq', 1, false);


--
-- Name: accounts_receivable_id_seq; Type: SEQUENCE SET; Schema: public; Owner: serviceflow
--

SELECT pg_catalog.setval('public.accounts_receivable_id_seq', 1, true);


--
-- Name: audit_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: serviceflow
--

SELECT pg_catalog.setval('public.audit_logs_id_seq', 11, true);


--
-- Name: cash_sessions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: serviceflow
--

SELECT pg_catalog.setval('public.cash_sessions_id_seq', 4, true);


--
-- Name: cash_transactions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: serviceflow
--

SELECT pg_catalog.setval('public.cash_transactions_id_seq', 12, true);


--
-- Name: categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: serviceflow
--

SELECT pg_catalog.setval('public.categories_id_seq', 5, true);


--
-- Name: customer_payments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: serviceflow
--

SELECT pg_catalog.setval('public.customer_payments_id_seq', 1, false);


--
-- Name: customers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: serviceflow
--

SELECT pg_catalog.setval('public.customers_id_seq', 2, true);


--
-- Name: exchange_rates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: serviceflow
--

SELECT pg_catalog.setval('public.exchange_rates_id_seq', 2, true);


--
-- Name: expense_categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: serviceflow
--

SELECT pg_catalog.setval('public.expense_categories_id_seq', 1, false);


--
-- Name: expenses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: serviceflow
--

SELECT pg_catalog.setval('public.expenses_id_seq', 1, false);


--
-- Name: inventory_id_seq; Type: SEQUENCE SET; Schema: public; Owner: serviceflow
--

SELECT pg_catalog.setval('public.inventory_id_seq', 4, true);


--
-- Name: inventory_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: serviceflow
--

SELECT pg_catalog.setval('public.inventory_logs_id_seq', 1, false);


--
-- Name: notifications_id_seq; Type: SEQUENCE SET; Schema: public; Owner: serviceflow
--

SELECT pg_catalog.setval('public.notifications_id_seq', 1, false);


--
-- Name: payments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: serviceflow
--

SELECT pg_catalog.setval('public.payments_id_seq', 5, true);


--
-- Name: products_id_seq; Type: SEQUENCE SET; Schema: public; Owner: serviceflow
--

SELECT pg_catalog.setval('public.products_id_seq', 4, true);


--
-- Name: purchase_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: serviceflow
--

SELECT pg_catalog.setval('public.purchase_items_id_seq', 1, false);


--
-- Name: purchase_orders_id_seq; Type: SEQUENCE SET; Schema: public; Owner: serviceflow
--

SELECT pg_catalog.setval('public.purchase_orders_id_seq', 1, false);


--
-- Name: repair_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: serviceflow
--

SELECT pg_catalog.setval('public.repair_items_id_seq', 2, true);


--
-- Name: repair_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: serviceflow
--

SELECT pg_catalog.setval('public.repair_logs_id_seq', 12, true);


--
-- Name: repairs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: serviceflow
--

SELECT pg_catalog.setval('public.repairs_id_seq', 2, true);


--
-- Name: roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: serviceflow
--

SELECT pg_catalog.setval('public.roles_id_seq', 4, true);


--
-- Name: sale_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: serviceflow
--

SELECT pg_catalog.setval('public.sale_items_id_seq', 3, true);


--
-- Name: sale_return_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: serviceflow
--

SELECT pg_catalog.setval('public.sale_return_items_id_seq', 1, false);


--
-- Name: sale_returns_id_seq; Type: SEQUENCE SET; Schema: public; Owner: serviceflow
--

SELECT pg_catalog.setval('public.sale_returns_id_seq', 1, false);


--
-- Name: sales_id_seq; Type: SEQUENCE SET; Schema: public; Owner: serviceflow
--

SELECT pg_catalog.setval('public.sales_id_seq', 5, true);


--
-- Name: suppliers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: serviceflow
--

SELECT pg_catalog.setval('public.suppliers_id_seq', 1, false);


--
-- Name: system_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: serviceflow
--

SELECT pg_catalog.setval('public.system_settings_id_seq', 1, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: serviceflow
--

SELECT pg_catalog.setval('public.users_id_seq', 1, true);


--
-- Name: accounts_payable accounts_payable_pkey; Type: CONSTRAINT; Schema: public; Owner: serviceflow
--

ALTER TABLE ONLY public.accounts_payable
    ADD CONSTRAINT accounts_payable_pkey PRIMARY KEY (id);


--
-- Name: accounts_receivable accounts_receivable_pkey; Type: CONSTRAINT; Schema: public; Owner: serviceflow
--

ALTER TABLE ONLY public.accounts_receivable
    ADD CONSTRAINT accounts_receivable_pkey PRIMARY KEY (id);


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: serviceflow
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: cash_sessions cash_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: serviceflow
--

ALTER TABLE ONLY public.cash_sessions
    ADD CONSTRAINT cash_sessions_pkey PRIMARY KEY (id);


--
-- Name: cash_sessions cash_sessions_session_code_key; Type: CONSTRAINT; Schema: public; Owner: serviceflow
--

ALTER TABLE ONLY public.cash_sessions
    ADD CONSTRAINT cash_sessions_session_code_key UNIQUE (session_code);


--
-- Name: cash_transactions cash_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: serviceflow
--

ALTER TABLE ONLY public.cash_transactions
    ADD CONSTRAINT cash_transactions_pkey PRIMARY KEY (id);


--
-- Name: categories categories_name_key; Type: CONSTRAINT; Schema: public; Owner: serviceflow
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_name_key UNIQUE (name);


--
-- Name: categories categories_pkey; Type: CONSTRAINT; Schema: public; Owner: serviceflow
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_pkey PRIMARY KEY (id);


--
-- Name: customer_payments customer_payments_pkey; Type: CONSTRAINT; Schema: public; Owner: serviceflow
--

ALTER TABLE ONLY public.customer_payments
    ADD CONSTRAINT customer_payments_pkey PRIMARY KEY (id);


--
-- Name: customers customers_pkey; Type: CONSTRAINT; Schema: public; Owner: serviceflow
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_pkey PRIMARY KEY (id);


--
-- Name: exchange_rates exchange_rates_effective_date_key; Type: CONSTRAINT; Schema: public; Owner: serviceflow
--

ALTER TABLE ONLY public.exchange_rates
    ADD CONSTRAINT exchange_rates_effective_date_key UNIQUE (effective_date);


--
-- Name: exchange_rates exchange_rates_pkey; Type: CONSTRAINT; Schema: public; Owner: serviceflow
--

ALTER TABLE ONLY public.exchange_rates
    ADD CONSTRAINT exchange_rates_pkey PRIMARY KEY (id);


--
-- Name: expense_categories expense_categories_name_key; Type: CONSTRAINT; Schema: public; Owner: serviceflow
--

ALTER TABLE ONLY public.expense_categories
    ADD CONSTRAINT expense_categories_name_key UNIQUE (name);


--
-- Name: expense_categories expense_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: serviceflow
--

ALTER TABLE ONLY public.expense_categories
    ADD CONSTRAINT expense_categories_pkey PRIMARY KEY (id);


--
-- Name: expenses expenses_pkey; Type: CONSTRAINT; Schema: public; Owner: serviceflow
--

ALTER TABLE ONLY public.expenses
    ADD CONSTRAINT expenses_pkey PRIMARY KEY (id);


--
-- Name: inventory_logs inventory_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: serviceflow
--

ALTER TABLE ONLY public.inventory_logs
    ADD CONSTRAINT inventory_logs_pkey PRIMARY KEY (id);


--
-- Name: inventory inventory_pkey; Type: CONSTRAINT; Schema: public; Owner: serviceflow
--

ALTER TABLE ONLY public.inventory
    ADD CONSTRAINT inventory_pkey PRIMARY KEY (id);


--
-- Name: inventory inventory_product_id_key; Type: CONSTRAINT; Schema: public; Owner: serviceflow
--

ALTER TABLE ONLY public.inventory
    ADD CONSTRAINT inventory_product_id_key UNIQUE (product_id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: serviceflow
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: payments payments_pkey; Type: CONSTRAINT; Schema: public; Owner: serviceflow
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_pkey PRIMARY KEY (id);


--
-- Name: products products_pkey; Type: CONSTRAINT; Schema: public; Owner: serviceflow
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_pkey PRIMARY KEY (id);


--
-- Name: purchase_items purchase_items_pkey; Type: CONSTRAINT; Schema: public; Owner: serviceflow
--

ALTER TABLE ONLY public.purchase_items
    ADD CONSTRAINT purchase_items_pkey PRIMARY KEY (id);


--
-- Name: purchase_orders purchase_orders_pkey; Type: CONSTRAINT; Schema: public; Owner: serviceflow
--

ALTER TABLE ONLY public.purchase_orders
    ADD CONSTRAINT purchase_orders_pkey PRIMARY KEY (id);


--
-- Name: repair_items repair_items_pkey; Type: CONSTRAINT; Schema: public; Owner: serviceflow
--

ALTER TABLE ONLY public.repair_items
    ADD CONSTRAINT repair_items_pkey PRIMARY KEY (id);


--
-- Name: repair_logs repair_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: serviceflow
--

ALTER TABLE ONLY public.repair_logs
    ADD CONSTRAINT repair_logs_pkey PRIMARY KEY (id);


--
-- Name: repairs repairs_pkey; Type: CONSTRAINT; Schema: public; Owner: serviceflow
--

ALTER TABLE ONLY public.repairs
    ADD CONSTRAINT repairs_pkey PRIMARY KEY (id);


--
-- Name: roles roles_name_key; Type: CONSTRAINT; Schema: public; Owner: serviceflow
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_name_key UNIQUE (name);


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: serviceflow
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- Name: sale_items sale_items_pkey; Type: CONSTRAINT; Schema: public; Owner: serviceflow
--

ALTER TABLE ONLY public.sale_items
    ADD CONSTRAINT sale_items_pkey PRIMARY KEY (id);


--
-- Name: sale_repairs sale_repairs_pkey; Type: CONSTRAINT; Schema: public; Owner: serviceflow
--

ALTER TABLE ONLY public.sale_repairs
    ADD CONSTRAINT sale_repairs_pkey PRIMARY KEY (sale_id, repair_id);


--
-- Name: sale_return_items sale_return_items_pkey; Type: CONSTRAINT; Schema: public; Owner: serviceflow
--

ALTER TABLE ONLY public.sale_return_items
    ADD CONSTRAINT sale_return_items_pkey PRIMARY KEY (id);


--
-- Name: sale_returns sale_returns_pkey; Type: CONSTRAINT; Schema: public; Owner: serviceflow
--

ALTER TABLE ONLY public.sale_returns
    ADD CONSTRAINT sale_returns_pkey PRIMARY KEY (id);


--
-- Name: sales sales_pkey; Type: CONSTRAINT; Schema: public; Owner: serviceflow
--

ALTER TABLE ONLY public.sales
    ADD CONSTRAINT sales_pkey PRIMARY KEY (id);


--
-- Name: suppliers suppliers_pkey; Type: CONSTRAINT; Schema: public; Owner: serviceflow
--

ALTER TABLE ONLY public.suppliers
    ADD CONSTRAINT suppliers_pkey PRIMARY KEY (id);


--
-- Name: system_settings system_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: serviceflow
--

ALTER TABLE ONLY public.system_settings
    ADD CONSTRAINT system_settings_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: serviceflow
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: ix_accounts_payable_id; Type: INDEX; Schema: public; Owner: serviceflow
--

CREATE INDEX ix_accounts_payable_id ON public.accounts_payable USING btree (id);


--
-- Name: ix_accounts_receivable_id; Type: INDEX; Schema: public; Owner: serviceflow
--

CREATE INDEX ix_accounts_receivable_id ON public.accounts_receivable USING btree (id);


--
-- Name: ix_accounts_receivable_status; Type: INDEX; Schema: public; Owner: serviceflow
--

CREATE INDEX ix_accounts_receivable_status ON public.accounts_receivable USING btree (status);


--
-- Name: ix_audit_logs_id; Type: INDEX; Schema: public; Owner: serviceflow
--

CREATE INDEX ix_audit_logs_id ON public.audit_logs USING btree (id);


--
-- Name: ix_cash_sessions_id; Type: INDEX; Schema: public; Owner: serviceflow
--

CREATE INDEX ix_cash_sessions_id ON public.cash_sessions USING btree (id);


--
-- Name: ix_cash_transactions_id; Type: INDEX; Schema: public; Owner: serviceflow
--

CREATE INDEX ix_cash_transactions_id ON public.cash_transactions USING btree (id);


--
-- Name: ix_categories_id; Type: INDEX; Schema: public; Owner: serviceflow
--

CREATE INDEX ix_categories_id ON public.categories USING btree (id);


--
-- Name: ix_customer_payments_id; Type: INDEX; Schema: public; Owner: serviceflow
--

CREATE INDEX ix_customer_payments_id ON public.customer_payments USING btree (id);


--
-- Name: ix_customers_credit_status; Type: INDEX; Schema: public; Owner: serviceflow
--

CREATE INDEX ix_customers_credit_status ON public.customers USING btree (credit_status);


--
-- Name: ix_customers_dni; Type: INDEX; Schema: public; Owner: serviceflow
--

CREATE INDEX ix_customers_dni ON public.customers USING btree (dni);


--
-- Name: ix_customers_email; Type: INDEX; Schema: public; Owner: serviceflow
--

CREATE INDEX ix_customers_email ON public.customers USING btree (email);


--
-- Name: ix_customers_id; Type: INDEX; Schema: public; Owner: serviceflow
--

CREATE INDEX ix_customers_id ON public.customers USING btree (id);


--
-- Name: ix_customers_name; Type: INDEX; Schema: public; Owner: serviceflow
--

CREATE INDEX ix_customers_name ON public.customers USING btree (name);


--
-- Name: ix_customers_phone; Type: INDEX; Schema: public; Owner: serviceflow
--

CREATE INDEX ix_customers_phone ON public.customers USING btree (phone);


--
-- Name: ix_exchange_rates_id; Type: INDEX; Schema: public; Owner: serviceflow
--

CREATE INDEX ix_exchange_rates_id ON public.exchange_rates USING btree (id);


--
-- Name: ix_expense_categories_id; Type: INDEX; Schema: public; Owner: serviceflow
--

CREATE INDEX ix_expense_categories_id ON public.expense_categories USING btree (id);


--
-- Name: ix_expenses_id; Type: INDEX; Schema: public; Owner: serviceflow
--

CREATE INDEX ix_expenses_id ON public.expenses USING btree (id);


--
-- Name: ix_inventory_id; Type: INDEX; Schema: public; Owner: serviceflow
--

CREATE INDEX ix_inventory_id ON public.inventory USING btree (id);


--
-- Name: ix_inventory_logs_id; Type: INDEX; Schema: public; Owner: serviceflow
--

CREATE INDEX ix_inventory_logs_id ON public.inventory_logs USING btree (id);


--
-- Name: ix_notifications_id; Type: INDEX; Schema: public; Owner: serviceflow
--

CREATE INDEX ix_notifications_id ON public.notifications USING btree (id);


--
-- Name: ix_payments_id; Type: INDEX; Schema: public; Owner: serviceflow
--

CREATE INDEX ix_payments_id ON public.payments USING btree (id);


--
-- Name: ix_products_id; Type: INDEX; Schema: public; Owner: serviceflow
--

CREATE INDEX ix_products_id ON public.products USING btree (id);


--
-- Name: ix_products_sku; Type: INDEX; Schema: public; Owner: serviceflow
--

CREATE UNIQUE INDEX ix_products_sku ON public.products USING btree (sku);


--
-- Name: ix_purchase_items_id; Type: INDEX; Schema: public; Owner: serviceflow
--

CREATE INDEX ix_purchase_items_id ON public.purchase_items USING btree (id);


--
-- Name: ix_purchase_orders_id; Type: INDEX; Schema: public; Owner: serviceflow
--

CREATE INDEX ix_purchase_orders_id ON public.purchase_orders USING btree (id);


--
-- Name: ix_purchase_orders_status; Type: INDEX; Schema: public; Owner: serviceflow
--

CREATE INDEX ix_purchase_orders_status ON public.purchase_orders USING btree (status);


--
-- Name: ix_repair_items_id; Type: INDEX; Schema: public; Owner: serviceflow
--

CREATE INDEX ix_repair_items_id ON public.repair_items USING btree (id);


--
-- Name: ix_repair_logs_id; Type: INDEX; Schema: public; Owner: serviceflow
--

CREATE INDEX ix_repair_logs_id ON public.repair_logs USING btree (id);


--
-- Name: ix_repairs_id; Type: INDEX; Schema: public; Owner: serviceflow
--

CREATE INDEX ix_repairs_id ON public.repairs USING btree (id);


--
-- Name: ix_roles_id; Type: INDEX; Schema: public; Owner: serviceflow
--

CREATE INDEX ix_roles_id ON public.roles USING btree (id);


--
-- Name: ix_sale_items_id; Type: INDEX; Schema: public; Owner: serviceflow
--

CREATE INDEX ix_sale_items_id ON public.sale_items USING btree (id);


--
-- Name: ix_sale_return_items_id; Type: INDEX; Schema: public; Owner: serviceflow
--

CREATE INDEX ix_sale_return_items_id ON public.sale_return_items USING btree (id);


--
-- Name: ix_sale_returns_id; Type: INDEX; Schema: public; Owner: serviceflow
--

CREATE INDEX ix_sale_returns_id ON public.sale_returns USING btree (id);


--
-- Name: ix_sales_id; Type: INDEX; Schema: public; Owner: serviceflow
--

CREATE INDEX ix_sales_id ON public.sales USING btree (id);


--
-- Name: ix_suppliers_id; Type: INDEX; Schema: public; Owner: serviceflow
--

CREATE INDEX ix_suppliers_id ON public.suppliers USING btree (id);


--
-- Name: ix_suppliers_name; Type: INDEX; Schema: public; Owner: serviceflow
--

CREATE INDEX ix_suppliers_name ON public.suppliers USING btree (name);


--
-- Name: ix_system_settings_id; Type: INDEX; Schema: public; Owner: serviceflow
--

CREATE INDEX ix_system_settings_id ON public.system_settings USING btree (id);


--
-- Name: ix_users_email; Type: INDEX; Schema: public; Owner: serviceflow
--

CREATE UNIQUE INDEX ix_users_email ON public.users USING btree (email);


--
-- Name: ix_users_id; Type: INDEX; Schema: public; Owner: serviceflow
--

CREATE INDEX ix_users_id ON public.users USING btree (id);


--
-- Name: ix_users_username; Type: INDEX; Schema: public; Owner: serviceflow
--

CREATE UNIQUE INDEX ix_users_username ON public.users USING btree (username);


--
-- Name: accounts_payable accounts_payable_purchase_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: serviceflow
--

ALTER TABLE ONLY public.accounts_payable
    ADD CONSTRAINT accounts_payable_purchase_order_id_fkey FOREIGN KEY (purchase_order_id) REFERENCES public.purchase_orders(id);


--
-- Name: accounts_payable accounts_payable_supplier_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: serviceflow
--

ALTER TABLE ONLY public.accounts_payable
    ADD CONSTRAINT accounts_payable_supplier_id_fkey FOREIGN KEY (supplier_id) REFERENCES public.suppliers(id);


--
-- Name: accounts_receivable accounts_receivable_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: serviceflow
--

ALTER TABLE ONLY public.accounts_receivable
    ADD CONSTRAINT accounts_receivable_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: accounts_receivable accounts_receivable_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: serviceflow
--

ALTER TABLE ONLY public.accounts_receivable
    ADD CONSTRAINT accounts_receivable_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customers(id);


--
-- Name: accounts_receivable accounts_receivable_repair_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: serviceflow
--

ALTER TABLE ONLY public.accounts_receivable
    ADD CONSTRAINT accounts_receivable_repair_id_fkey FOREIGN KEY (repair_id) REFERENCES public.repairs(id);


--
-- Name: accounts_receivable accounts_receivable_sale_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: serviceflow
--

ALTER TABLE ONLY public.accounts_receivable
    ADD CONSTRAINT accounts_receivable_sale_id_fkey FOREIGN KEY (sale_id) REFERENCES public.sales(id);


--
-- Name: audit_logs audit_logs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: serviceflow
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: cash_sessions cash_sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: serviceflow
--

ALTER TABLE ONLY public.cash_sessions
    ADD CONSTRAINT cash_sessions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: cash_transactions cash_transactions_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: serviceflow
--

ALTER TABLE ONLY public.cash_transactions
    ADD CONSTRAINT cash_transactions_session_id_fkey FOREIGN KEY (session_id) REFERENCES public.cash_sessions(id);


--
-- Name: customer_payments customer_payments_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: serviceflow
--

ALTER TABLE ONLY public.customer_payments
    ADD CONSTRAINT customer_payments_account_id_fkey FOREIGN KEY (account_id) REFERENCES public.accounts_receivable(id);


--
-- Name: customer_payments customer_payments_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: serviceflow
--

ALTER TABLE ONLY public.customer_payments
    ADD CONSTRAINT customer_payments_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: customer_payments customer_payments_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: serviceflow
--

ALTER TABLE ONLY public.customer_payments
    ADD CONSTRAINT customer_payments_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customers(id);


--
-- Name: customer_payments customer_payments_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: serviceflow
--

ALTER TABLE ONLY public.customer_payments
    ADD CONSTRAINT customer_payments_session_id_fkey FOREIGN KEY (session_id) REFERENCES public.cash_sessions(id);


--
-- Name: expenses expenses_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: serviceflow
--

ALTER TABLE ONLY public.expenses
    ADD CONSTRAINT expenses_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.expense_categories(id);


--
-- Name: expenses expenses_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: serviceflow
--

ALTER TABLE ONLY public.expenses
    ADD CONSTRAINT expenses_session_id_fkey FOREIGN KEY (session_id) REFERENCES public.cash_sessions(id);


--
-- Name: expenses expenses_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: serviceflow
--

ALTER TABLE ONLY public.expenses
    ADD CONSTRAINT expenses_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: inventory_logs inventory_logs_inventory_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: serviceflow
--

ALTER TABLE ONLY public.inventory_logs
    ADD CONSTRAINT inventory_logs_inventory_id_fkey FOREIGN KEY (inventory_id) REFERENCES public.inventory(id);


--
-- Name: inventory_logs inventory_logs_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: serviceflow
--

ALTER TABLE ONLY public.inventory_logs
    ADD CONSTRAINT inventory_logs_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id);


--
-- Name: inventory_logs inventory_logs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: serviceflow
--

ALTER TABLE ONLY public.inventory_logs
    ADD CONSTRAINT inventory_logs_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: inventory inventory_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: serviceflow
--

ALTER TABLE ONLY public.inventory
    ADD CONSTRAINT inventory_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id);


--
-- Name: notifications notifications_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: serviceflow
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: payments payments_repair_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: serviceflow
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_repair_id_fkey FOREIGN KEY (repair_id) REFERENCES public.repairs(id);


--
-- Name: payments payments_sale_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: serviceflow
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_sale_id_fkey FOREIGN KEY (sale_id) REFERENCES public.sales(id);


--
-- Name: payments payments_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: serviceflow
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_session_id_fkey FOREIGN KEY (session_id) REFERENCES public.cash_sessions(id);


--
-- Name: products products_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: serviceflow
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.categories(id);


--
-- Name: purchase_items purchase_items_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: serviceflow
--

ALTER TABLE ONLY public.purchase_items
    ADD CONSTRAINT purchase_items_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id);


--
-- Name: purchase_items purchase_items_purchase_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: serviceflow
--

ALTER TABLE ONLY public.purchase_items
    ADD CONSTRAINT purchase_items_purchase_id_fkey FOREIGN KEY (purchase_id) REFERENCES public.purchase_orders(id);


--
-- Name: purchase_orders purchase_orders_supplier_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: serviceflow
--

ALTER TABLE ONLY public.purchase_orders
    ADD CONSTRAINT purchase_orders_supplier_id_fkey FOREIGN KEY (supplier_id) REFERENCES public.suppliers(id);


--
-- Name: purchase_orders purchase_orders_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: serviceflow
--

ALTER TABLE ONLY public.purchase_orders
    ADD CONSTRAINT purchase_orders_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: repair_items repair_items_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: serviceflow
--

ALTER TABLE ONLY public.repair_items
    ADD CONSTRAINT repair_items_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id);


--
-- Name: repair_items repair_items_repair_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: serviceflow
--

ALTER TABLE ONLY public.repair_items
    ADD CONSTRAINT repair_items_repair_id_fkey FOREIGN KEY (repair_id) REFERENCES public.repairs(id);


--
-- Name: repair_logs repair_logs_repair_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: serviceflow
--

ALTER TABLE ONLY public.repair_logs
    ADD CONSTRAINT repair_logs_repair_id_fkey FOREIGN KEY (repair_id) REFERENCES public.repairs(id);


--
-- Name: repair_logs repair_logs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: serviceflow
--

ALTER TABLE ONLY public.repair_logs
    ADD CONSTRAINT repair_logs_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: repairs repairs_created_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: serviceflow
--

ALTER TABLE ONLY public.repairs
    ADD CONSTRAINT repairs_created_by_id_fkey FOREIGN KEY (created_by_id) REFERENCES public.users(id);


--
-- Name: repairs repairs_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: serviceflow
--

ALTER TABLE ONLY public.repairs
    ADD CONSTRAINT repairs_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customers(id);


--
-- Name: repairs repairs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: serviceflow
--

ALTER TABLE ONLY public.repairs
    ADD CONSTRAINT repairs_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: sale_items sale_items_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: serviceflow
--

ALTER TABLE ONLY public.sale_items
    ADD CONSTRAINT sale_items_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id);


--
-- Name: sale_items sale_items_sale_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: serviceflow
--

ALTER TABLE ONLY public.sale_items
    ADD CONSTRAINT sale_items_sale_id_fkey FOREIGN KEY (sale_id) REFERENCES public.sales(id);


--
-- Name: sale_repairs sale_repairs_repair_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: serviceflow
--

ALTER TABLE ONLY public.sale_repairs
    ADD CONSTRAINT sale_repairs_repair_id_fkey FOREIGN KEY (repair_id) REFERENCES public.repairs(id);


--
-- Name: sale_repairs sale_repairs_sale_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: serviceflow
--

ALTER TABLE ONLY public.sale_repairs
    ADD CONSTRAINT sale_repairs_sale_id_fkey FOREIGN KEY (sale_id) REFERENCES public.sales(id);


--
-- Name: sale_return_items sale_return_items_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: serviceflow
--

ALTER TABLE ONLY public.sale_return_items
    ADD CONSTRAINT sale_return_items_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id);


--
-- Name: sale_return_items sale_return_items_sale_return_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: serviceflow
--

ALTER TABLE ONLY public.sale_return_items
    ADD CONSTRAINT sale_return_items_sale_return_id_fkey FOREIGN KEY (sale_return_id) REFERENCES public.sale_returns(id);


--
-- Name: sale_returns sale_returns_sale_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: serviceflow
--

ALTER TABLE ONLY public.sale_returns
    ADD CONSTRAINT sale_returns_sale_id_fkey FOREIGN KEY (sale_id) REFERENCES public.sales(id);


--
-- Name: sale_returns sale_returns_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: serviceflow
--

ALTER TABLE ONLY public.sale_returns
    ADD CONSTRAINT sale_returns_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: sales sales_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: serviceflow
--

ALTER TABLE ONLY public.sales
    ADD CONSTRAINT sales_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customers(id);


--
-- Name: sales sales_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: serviceflow
--

ALTER TABLE ONLY public.sales
    ADD CONSTRAINT sales_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: user_roles user_roles_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: serviceflow
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.roles(id);


--
-- Name: user_roles user_roles_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: serviceflow
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- PostgreSQL database dump complete
--

\unrestrict d4ix1xmMMi68bXYCOaUQPUmEGSCyLE8F8r2gZbfRYDpOfMhFUcfCWd6mOh7xyif

